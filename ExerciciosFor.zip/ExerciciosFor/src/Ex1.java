public class Ex1 {

    public void exibirMensagem(){
        for (int i=0; i<20; i++) {
            if (i<20){
            System.out.println("Eu gosto de estudar Algoritmos!" + i);}
        }
    }
}


//1) Escreva um algoritmo que exiba 20 vezes a mensagem “Eu gosto de estudar Algoritmos!”.