import java.util.Scanner;

public class Ex16 {
}

//1. Escreva um algoritmo em PORTUGOL que leia um número e informe se ele é divisível por 10,
// por 5 ou por 2 ou se não é divisível por nenhum deles.