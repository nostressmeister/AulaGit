
public class Main {
    public static void main(String[] args) {

        //Ex1 ex1 = new Ex1();
        //ex1.exibirMensagem();

        //Ex2 ex2 = new Ex2();
        //ex2.somaNumeros();

        //Ex3 ex3 = new Ex3();
        //ex3.nomeUsuario();

        //Ex4 ex4 = new Ex4();
        //ex4.nomeNumero();

        //Ex5 ex5 = new Ex5();
        //ex5.calculoSoma();

       // Ex6 ex6 = new Ex6();
        //ex6.somaIdade();

        //Ex7 ex7 = new Ex7();
        //ex7.mediaIdade();

        //Ex8 ex8 = new Ex8();
        //ex8.pessoasMaiores();

        //Ex9 ex9 = new Ex9();
        //ex9.pessoaNova();

        //Ex10 ex10 = new Ex10();
        //ex10.tabuadaNumero();

        //Ex11 ex11 = new Ex11();
        //ex11.numerosMaiores();

        //Ex12 ex12 = new Ex12();
        //ex12.numerosPares();

        //Ex13 ex13 = new Ex13();
        //ex13.numerosCem();

        //Ex14 ex14 = new Ex14();
        //ex14.intervaloNumeros();

        //Ex15 ex15 = new Ex15();
        //ex15.numerosSoma();

//        ConexaoH2 conexaoH2 = new ConexaoH2();
//        conexaoH2.insert();
        //conexaoH2.delet();
        //conexaoH2.select();
        //conexaoH2.selectOne();
        //conexaoH2.upDate();

        ConexaoExsql conexaoExsql = new ConexaoExsql();
        conexaoExsql.insert();
        conexaoExsql.select();

        }
    }




