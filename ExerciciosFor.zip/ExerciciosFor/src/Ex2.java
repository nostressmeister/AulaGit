public class Ex2 {

    public void somaNumeros(){
            int soma = 0;
        for(int i=1; i<16 ; i++){
            int result = (soma+i);
            soma = result;
            System.out.println(soma);
            }

    }
}

//2) Escreva um algoritmo que calcule a soma dos números de 1 a 15.